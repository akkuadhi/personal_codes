import subprocess
import re

def get_edge_version():
    """Gets the version of Edge running on the system."""
    msedgeExe = r"C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
    cmdArgs = ["wmic", "DATAFILE", "WHERE", r"NAME='{0}'".format(msedgeExe), "GET", "Version", "/value"]
    process = subprocess.check_output(cmdArgs)
    edgeversion = re.sub("Version=", "", process.strip().decode())
    edge_version_cleaner_list = edgeversion.split(".")
    print(edge_version_cleaner_list)
    edge_version = ".".join(edge_version_cleaner_list[0:4])
    return edge_version
def get_edgedriver_version(edge_version):
    """Gets the version of EdgeDriver that is compatible with the specified Edge version."""
    edgedriver_version_url = "https://developer.microsoft.com/en-us/microsoft-edge/tools/webdriver/"
    html_content = subprocess.check_output(["curl", "-s", edgedriver_version_url]).decode("utf-8")

    # Find the latest EdgeDriver version that is compatible with the specified Edge version.
    latest_edgedriver_version = None
    for match in re.finditer(r"(?<=Release )\d+\.\d+\.\d+\.\d+", html_content):
        edgedriver_version = match.group(0)
        if edgedriver_version >= edge_version:
            latest_edgedriver_version = edgedriver_version

    return latest_edgedriver_version

if __name__ == "__main__":
    edge_version = get_edge_version()
    edgedriver_version = get_edgedriver_version(edge_version)
    print("The correct version of EdgeDriver for Edge {} is {}".format(edge_version, edgedriver_version))