import subprocess
import re


def get_chrome_version():
    """Gets the version of Chrome running on the system."""
    chrome_exe = r"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
    cmdArgs = ["wmic", "DATAFILE", "WHERE", r"NAME='{0}'".format(chrome_exe), "GET", "Version", "/value"]
    process = subprocess.check_output(cmdArgs)
    chromeversion = re.sub("Version=", "", process.strip().decode())
    chrome_version_cleaner_list = chromeversion.split(".")
    print(chrome_version_cleaner_list)
    chrome_version = ".".join(chrome_version_cleaner_list[0:4])
    return chrome_version


def get_edge_version():
    """Gets the version of Edge running on the system."""
    msedgeExe = r"C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe"
    cmdArgs = ["wmic", "DATAFILE", "WHERE", r"NAME='{0}'".format(msedgeExe), "GET", "Version", "/value"]
    process = subprocess.check_output(cmdArgs)
    edgeversion = re.sub("Version=", "", process.strip().decode())
    edge_version_cleaner_list = edgeversion.split(".")
    print(edge_version_cleaner_list)
    edge_version = ".".join(edge_version_cleaner_list[0:4])
    return edge_version


def install_selenium_webdriver(browser, version):
    """Installs the compatible version of Selenium WebDriver for the specified browser and version."""
    package_name = "Selenium.WebDriver.{0}".format(browser)
    package_version = "{}".format(version)
    command = "nuget install {0} -Version {1}".format(package_name, package_version)
    subprocess.run(command, shell=True)


def main():
    """Main function."""
    chrome_version = get_chrome_version()
    edge_version = get_edge_version()

    # Install Selenium Chrome WebDriver.
    install_selenium_webdriver("Chrome", chrome_version)

    # Install Selenium Edge WebDriver.
    install_selenium_webdriver("MSEdgeDriver ", edge_version)


if __name__ == "__main__":
    main()
