import subprocess
import re

def get_chrome_version():
    """Gets the version of Chrome running on the system."""
    chrome_exe = r"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
    cmdArgs = ["wmic", "DATAFILE", "WHERE", r"NAME='{0}'".format(chrome_exe), "GET", "Version", "/value"]
    process = subprocess.check_output(cmdArgs)
    chromeversion = re.sub("Version=", "", process.strip().decode())
    chrome_version_cleaner_list = chromeversion.split(".")
    print(chrome_version_cleaner_list)
    chrome_version = ".".join(chrome_version_cleaner_list[0:4])
    return chrome_version

def get_chromedriver_version(chrome_version):
    """Gets the version of ChromeDriver that is compatible with the specified Chrome version."""
    chromedriver_version_url = "https://chromedriver.storage.googleapis.com/LATEST_RELEASE_" + chrome_version.split(".")[0]
    chromedriver_version = subprocess.check_output(["curl", "-s", chromedriver_version_url]).decode("utf-8").strip()
    return chromedriver_version

if __name__ == "__main__":
    chrome_version = get_chrome_version()
    chromedriver_version = get_chromedriver_version(chrome_version)
    print("The correct version of ChromeDriver for Chrome {} is {}".format(chrome_version, chromedriver_version))